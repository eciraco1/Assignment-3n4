#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <setjmp.h>
#include <unistd.h>
#include <string.h>
int g=10;
jmp_buf buff;

void longjmp(jmp_buf env, int val);
void save_state(void *addr, unsigned int s);


typedef struct var_state{
    char *address;
    unsigned int size;
    unsigned char * data;
    struct var_state *next;
}var_state;

var_state *var_state_head;

void restore_state(){
  var_state *t;
  while(var_state_head != NULL){
    memcpy(var_state_head->address, var_state_head->data, var_state_head->size);
    free(var_state_head->data);
    free (var_state_head);
    var_state_head=t;
  }
}

void save_state(void *addr, unsigned int s){
  unsigned char * ap= (unsigned char*) addr;
  var_state *h=malloc(sizeof(var_state));
  h->address=(char *)addr;
  h->data=malloc(sizeof(*addr));
  for(int i=0; i<s; i++){
    h->data[i]=ap[i];
  }
  h->size=s;

  if(var_state_head==NULL){
    var_state_head=h;
  }else{
    var_state *temp;
    temp=var_state_head;
    while(temp->next!=NULL){
      temp=temp->next;
    }
    temp->next=h;
  }
}

int handler(int signum){
  if(signum>0 && signum<64){
    printf("Shits handled b: %d", signum);
    longjmp(buff, signum);
  }
}

void f(){
  int g=30;
  int x;
  char *p;
  x=11;
  p= (char *) malloc(2*sizeof(char));
  p[0]=p[1]='x';

//register signal handler for all the signals
  for(int i=0; i<64; i++){
    signal(i, handler(i));
  }
  int *xp;
  *xp=x;
  int *gp;
  *gp=g;
  void *pp=(void *)&p;
  void *p1p=(void *)&p[0];
  void *p2p=(void *)&p[1];

  save_state(xp, sizeof(int *));
  save_state(gp, sizeof(int *));
  save_state(pp, sizeof(char *));
  save_state(p1p, sizeof(char *));
  save_state(p2p, sizeof(char *));

  if(!setjmp(buff)){
    g=30;
    x=100;
    p=0;
  }else{
    restore_state();
    printf("%d, %d, %c, %c\n", g, x, p[0], p[1]);
  }

}
