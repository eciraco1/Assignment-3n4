#include <stdio.h>
#include <stdlib.h>

typedef void(*Calc_fptr)(void);

int main(int argc, char *argv[]){
  FILE *fp;
  typedef int (*Calc_fptr) (char, int, int);
  Calc_fptr calculator;
  unsigned int i;

  //gets # of bytes in file and allocates for raw_bytes
  fp= fopen(argv[0], "rb");
  fseek(fp, 0, SEEK_END);
  unsigned long length=ftell(fp);
  fclose(fp);

  unsigned char *raw_bytes;
  raw_bytes = malloc((length)*sizeof(char));


  //if # arguments != 5 print erro message and exit
  if(argc!=5){
    printf("Usage %s <filename><uint><operation><uint>\n", argv[0]);
    return 0;
  }

  //reads in bytes
  fp= fopen(argv[1], "rb");
  int j;
  for(j=0; j<=length; j++)
  fread(raw_bytes, length, 1, fp);
  fclose(fp);


  //converts second and fourth argument
  int arg1= atoi(argv[2]);
  int arg2= atoi(argv[4]);

  //gets operand sign
  char *s = (argv[3]);
  char sign= *s;


  //calculates and prints
  calculator=(Calc_fptr) raw_bytes;
  i= calculator(sign, arg1, arg2);
  printf("%d %c %d = %d\n", arg1, sign, arg2, i);
  return 0;
}
