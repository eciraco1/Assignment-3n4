#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct lines{
     char vbit;
     char *tag;
     char *data;
     int counter;
}Line;

void increment(Line *cache, int index, int second);
int getGreatest(Line *cache);
char* convert(char* hex);


int main(int argc, char* argv[]){
  FILE *fp;
  char * line= NULL;
  size_t len=0;
  fp= fopen("input.txt", "r");
  Line cache[2][4];
  for(int one=0; one<2; one++){
	for(int two=0; two<4; two++){
		cache[one][two].tag=malloc(sizeof(char)*5);
		memcpy(cache[one][two].tag, "00000", 5*sizeof(char));
		cache[one][two].vbit='0';
		cache[one][two].counter=0;
	}
  }

  //reads in file
  while((getline(&line, &len, fp))!=-1){
    int index;
    char* byt= convert(line);
    char *t=(char *)malloc(5);
    if(byt[5]=='0')
      index=0;
    else
      index=1;




    //gets the tag and puts it in t
    for(int a=0; a<5; a++){
      t[a]= byt[a];

    }
    int done=0; //if 1, hit, if 0, miss

    //if hit-------------------------------------------------------------
    for(int i=0; i<4; i++){
      if(((cache[index][i].vbit)!='0')
	&& (strcmp((cache[index][i].tag), t) == 0)){
        printf("HIT\n");
        cache[index][i].counter=0;
        done=1;
        increment(&cache[0][0], index, i);
	//insert data
        break;
      }
    }
    //if miss and there is an empty spot---------------------------------
    if(done==0){
      for(int s=0; s<4; s++){
        //check for hit
        if(cache[index][s].vbit=='0'){
          printf("MISS\n");
	  cache[index][s].vbit=1;
          cache[index][s].counter=0;
          increment(&cache[0][0], index, s);
	  memcpy(cache[index][s].tag, t, 5*sizeof(char));
	  cache[index][s].vbit='1';
	  done=1;
          break;
        }
      }
    }

    //if miss and there is not empty spot----------------------------------
      //set tag and data
      if(done==0){
	int highest=0;
	int hi=0;
      for(int p=0; p<4; p++){
        if(cache[index][p].counter>=highest){
	  highest= cache[index][p].counter;
	  hi=p;
	}
	}
          printf("MISS\n");
          cache[index][hi].counter=0;
          increment(&cache[0][0], index, hi);
          //set vbit, tag, and data
	  memcpy(cache[index][hi].tag, t, 5*sizeof(char));
	  done=1;
      }
	//prints entire cache
	/*
	for(int o=0; o<2; o++){
		printf("--------------------------------------------------------------\n");
	for(int u=0; u<4; u++){
		printf("Instruction: %s Valid Bit: %c Tag: %s\n", byt, cache[o][u].vbit, cache[o][u].tag);
	}
	printf("\n");*/
    }
    fclose(fp);
    if(line)
      free(line);
    exit(EXIT_SUCCESS);
  }


char* convert(char* hex){
  int i=0;
  char *binary;
  binary=(char *)malloc(8);
  if(strlen(hex)==2){
    strcat(binary, "0000");
  }
  while (hex[i]){
      switch (hex[i])
      {
      case '0':
        strcat(binary, "0000"); break;
      case '1':
        strcat(binary, "0001"); break;
      case '2':
        strcat(binary, "0010"); break;
      case '3':
        strcat(binary,"0011"); break;
      case '4':
        strcat(binary, "0100"); break;
      case '5':
        strcat(binary, "0101"); break;
      case '6':
        strcat(binary, "0110"); break;
      case '7':
        strcat(binary, "0111"); break;
      case '8':
        strcat(binary, "1000"); break;
      case '9':
        strcat(binary, "1001"); break;
      case 'a':
        strcat(binary, "1010"); break;
      case 'b':
        strcat(binary, "1011"); break;
      case 'c':
        strcat(binary, "1100"); break;
      case 'd':
        strcat(binary, "1101"); break;
      case 'e':
        strcat(binary, "1110"); break;
      case 'f':
        strcat(binary, "1111"); break;
      default: return binary; break;
      }
      i++;
    }
    return binary;
}


void increment(Line *cache, int index, int second){
  for(int i=0; i<2; i++){
    for(int j=0; j<4; j++){
      if(i!=index && j!=second){
        ((cache+i*4) + j)->counter++;
      }
    }
  }
}

int getGreatest(Line *cache){
  int greatest=0;
  int ret;
  for(int j=0; j<4; j++){
    if(cache[j].counter>greatest){
        greatest=cache[j].counter;
        ret=j;
    }
  }
  return ret;
}
